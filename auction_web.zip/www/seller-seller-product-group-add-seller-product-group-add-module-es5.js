(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["seller-seller-product-group-add-seller-product-group-add-module"], {
    /***/
    "JYeT":
    /*!********************************************************************************************!*\
      !*** ./src/app/seller/seller-product-group-add/seller-product-group-add-routing.module.ts ***!
      \********************************************************************************************/

    /*! exports provided: SellerProductGroupAddPageRoutingModule */

    /***/
    function JYeT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SellerProductGroupAddPageRoutingModule", function () {
        return SellerProductGroupAddPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _seller_product_group_add_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./seller-product-group-add.page */
      "yG7C");

      var routes = [{
        path: '',
        component: _seller_product_group_add_page__WEBPACK_IMPORTED_MODULE_3__["SellerProductGroupAddPage"]
      }];

      var SellerProductGroupAddPageRoutingModule = function SellerProductGroupAddPageRoutingModule() {
        _classCallCheck(this, SellerProductGroupAddPageRoutingModule);
      };

      SellerProductGroupAddPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SellerProductGroupAddPageRoutingModule);
      /***/
    },

    /***/
    "OElv":
    /*!************************************************************************************!*\
      !*** ./src/app/seller/seller-product-group-add/seller-product-group-add.module.ts ***!
      \************************************************************************************/

    /*! exports provided: SellerProductGroupAddPageModule */

    /***/
    function OElv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SellerProductGroupAddPageModule", function () {
        return SellerProductGroupAddPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _seller_product_group_add_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./seller-product-group-add-routing.module */
      "JYeT");
      /* harmony import */


      var _seller_product_group_add_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./seller-product-group-add.page */
      "yG7C");

      var SellerProductGroupAddPageModule = function SellerProductGroupAddPageModule() {
        _classCallCheck(this, SellerProductGroupAddPageModule);
      };

      SellerProductGroupAddPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _seller_product_group_add_routing_module__WEBPACK_IMPORTED_MODULE_5__["SellerProductGroupAddPageRoutingModule"]],
        declarations: [_seller_product_group_add_page__WEBPACK_IMPORTED_MODULE_6__["SellerProductGroupAddPage"]]
      })], SellerProductGroupAddPageModule);
      /***/
    },

    /***/
    "wOM3":
    /*!************************************************************************************!*\
      !*** ./src/app/seller/seller-product-group-add/seller-product-group-add.page.scss ***!
      \************************************************************************************/

    /*! exports provided: default */

    /***/
    function wOM3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZWxsZXItcHJvZHVjdC1ncm91cC1hZGQucGFnZS5zY3NzIn0= */";
      /***/
    },

    /***/
    "yG7C":
    /*!**********************************************************************************!*\
      !*** ./src/app/seller/seller-product-group-add/seller-product-group-add.page.ts ***!
      \**********************************************************************************/

    /*! exports provided: SellerProductGroupAddPage */

    /***/
    function yG7C(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SellerProductGroupAddPage", function () {
        return SellerProductGroupAddPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_seller_product_group_add_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./seller-product-group-add.page.html */
      "zPt1");
      /* harmony import */


      var _seller_product_group_add_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./seller-product-group-add.page.scss */
      "wOM3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");

      var SellerProductGroupAddPage = /*#__PURE__*/function () {
        function SellerProductGroupAddPage(http, loadingController, alertController) {
          _classCallCheck(this, SellerProductGroupAddPage);

          this.http = http;
          this.loadingController = loadingController;
          this.alertController = alertController;
          this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL;
          this.emailFormArray = [];
          this.group_name = '';
        }

        _createClass(SellerProductGroupAddPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.productList();
            this.groupsList();
          }
        }, {
          key: "groupsList",
          value: function groupsList() {
            var _this = this;

            var formData = new FormData();
            formData.append('', '');
            this.http.post(this.url + 'group-all-list', formData).subscribe(function (res) {
              //console.log(res);
              if (res && res.status) {
                _this.groupList = res.response_data;
              } else {
                _this.groupList = null;
              }
            });
          }
        }, {
          key: "onChange",
          value: function onChange(email, isChecked) {
            if (isChecked) {
              this.emailFormArray.push(email);
            } else {
              this.emailFormArray.splice(this.emailFormArray.indexOf(email), 1);
            }
          }
        }, {
          key: "getGroupid",
          value: function getGroupid(id) {
            var _this2 = this;

            this.productList(); //console.log(id);

            var formData = new FormData();
            formData.append('group_id', id);
            this.http.post(this.url + 'group-item-get', formData).subscribe(function (res) {
              //console.log(res);
              if (res && res.status) {
                _this2.grp_id = id;

                var _iterator = _createForOfIteratorHelper(_this2.pList2),
                    _step;

                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    var pro = _step.value;

                    var _iterator2 = _createForOfIteratorHelper(res.response_data),
                        _step2;

                    try {
                      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                        var p = _step2.value;

                        if (p.product_id == pro.id && p.category_group_id == id) {
                          pro.is_front = 1;
                          pro.is_front_two = p.id; //break;
                        }
                      }
                    } catch (err) {
                      _iterator2.e(err);
                    } finally {
                      _iterator2.f();
                    }
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }

                _this2.pList = _this2.pList2; //console.log(this.pList);
                // this.groupList = res.response_data;
              } else {
                _this2.pList = null;
              }
            });
          }
        }, {
          key: "productAdd",
          value: function productAdd() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this3 = this;

              var i, formData;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      if (this.group_name == '' || this.group_name == null) {
                        this.alertController.create({
                          message: 'Please select group name',
                          buttons: ['OK']
                        }).then(function (resalert) {
                          resalert.present();
                        });
                      } else if (this.emailFormArray == '') {
                        this.alertController.create({
                          message: 'Please select product',
                          buttons: ['OK']
                        }).then(function (resalert) {
                          resalert.present();
                        });
                      } else {
                        for (i = 0; i < this.emailFormArray.length; i++) {
                          //console.log(this.emailFormArray[i]);
                          formData = new FormData();
                          formData.append('category_group_id', this.group_name);
                          formData.append('product_id', this.emailFormArray[i]);
                          this.http.post(this.url + 'group-item-add', formData).subscribe(function (res) {
                            //this.res = res;
                            //console.log(res);
                            if (res.status) {
                              _this3.alertController.create({
                                message: res.message,
                                buttons: ['OK']
                              }).then(function (resalert) {
                                resalert.present();
                              });

                              _this3.getGroupid(_this3.group_name);
                            } else {
                              _this3.alertController.create({
                                message: 'Something went wrong, try again',
                                buttons: ['OK']
                              }).then(function (resalert) {
                                resalert.present();
                              });
                            }
                          });
                        }
                      }

                    case 1:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "productList",
          value: function productList() {
            var _this4 = this;

            var formData = new FormData();
            formData.append('', '');
            this.http.post(this.url + 'product-list', formData).subscribe(function (res) {
              if (res && res.status) {
                _this4.pList2 = res.response_data;
              } else {
                _this4.pList2 = null;
              }
            });
          }
        }, {
          key: "deleteProduct",
          value: function deleteProduct(p, grupid) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this5 = this;

              var formData, successalrt, fail, alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      //this.loadingShow();
                      formData = new FormData();
                      formData.append('group_item_id', grupid);
                      _context2.next = 4;
                      return this.alertController.create({
                        message: 'Data successfully delete',
                        buttons: ['OK']
                      });

                    case 4:
                      successalrt = _context2.sent;
                      _context2.next = 7;
                      return this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                      });

                    case 7:
                      fail = _context2.sent;
                      _context2.next = 10;
                      return this.alertController.create({
                        message: 'Are you sure to delete',
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler(blah) {//console.log('Confirm Cancel: blah');
                          }
                        }, {
                          text: 'Okay',
                          handler: function handler() {
                            //console.log('Confirm Okay');
                            if (p.id) {
                              _this5.loadingShow();

                              _this5.http.post(_this5.url + 'group-item-remove', formData).subscribe(function (res) {
                                // this.res = res.json();
                                //console.log(res);
                                if (res.status == false) {
                                  fail.present();

                                  _this5.loadingHide();
                                } else if (res.status == true) {
                                  successalrt.present(); //this.constructor();
                                  //this.navCtrl.navigateForward('address-list');

                                  //this.constructor();
                                  //this.navCtrl.navigateForward('address-list');
                                  _this5.loadingHide();

                                  _this5.getGroupid(_this5.grp_id);
                                } else {
                                  //alert("Server error");
                                  _this5.loadingHide();
                                }
                              }, function (err) {
                                console.log(err);

                                _this5.loadingHide();
                              });
                            }
                          }
                        }]
                      });

                    case 10:
                      alert = _context2.sent;
                      _context2.next = 13;
                      return alert.present();

                    case 13:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "editProduct",
          value: function editProduct(c) {}
        }, {
          key: "loadingShow",
          value: function loadingShow() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.loadingController.create({
                        message: 'Please wait...'
                      });

                    case 2:
                      this.loading = _context3.sent;
                      _context3.next = 5;
                      return this.loading.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "loadingHide",
          value: function loadingHide() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }]);

        return SellerProductGroupAddPage;
      }();

      SellerProductGroupAddPage.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      SellerProductGroupAddPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-seller-product-group-add',
        template: _raw_loader_seller_product_group_add_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_seller_product_group_add_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SellerProductGroupAddPage);
      /***/
    },

    /***/
    "zPt1":
    /*!**************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/seller/seller-product-group-add/seller-product-group-add.page.html ***!
      \**************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function zPt1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button autoHide=\"true\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Product add to group</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"row\">\n    <div class=\"col-lg-12\">\n      <div class=\"card\">\n        <!-- <div class=\"card-header\">\n          <i class=\"fa fa-align-justify\"></i> Products...\n        </div> -->\n        <div class=\"row\" style=\"margin-top: 7px;margin-left: 5px;\">\n          <div class=\"col-md-4\">\n            <select  class=\"form-control\" [(ngModel)]=\"group_name\" [ngModelOptions]=\"{standalone:true}\" (change)=\"getGroupid($event.target.value)\">\n            <option value=\"\" selected>Select group</option>\n            <option *ngFor=\"let gl of groupList\"   value=\"{{gl.id}}\">{{gl.category_group_name}}</option>\n          </select>\n          </div>\n          <div class=\"col-md-2\">\n           <button class=\"btn btn-sm1 btn-primary\" title=\"Click here to add\" (click)=\"productAdd()\"> Save</button>\n          </div>\n          \n        </div>\n        <div class=\"card-body\">\n          <table class=\"table table-bordered table-striped table-sm\">\n            <thead>\n              <tr>\n                <th>Title</th>\n                <th>\n                  Sort Description\n                </th>\n                <th>Bid Starting Price</th>\n                <th>Status</th>\n                <th>Action</th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr *ngFor=\"let p of pList\">\n                <td>{{p.product_name}}</td>\n                <td>\n                  {{p.product_short_description}}\n                </td>\n                <td>{{p.product_bid_starting_price}}</td>\n                <td><button *ngIf=\"p.status=='1'\"  class=\"btn btn-sm btn-success\" ><i class=\"fa fa-check-circle\" aria-hidden=\"true\"></i> Active</button>\n                  <button *ngIf=\"p.status=='0'\"  class=\"btn btn-sm btn-warning\" ><i class=\"fa fa-times-circle-o \" aria-hidden=\"true\"></i> Deactive</button>\n                </td>\n                <td>\n                              \n                   <div *ngIf=\"p.is_front==1\" >\n                      <input type=\"checkbox\" value=\"{{p.id}}\"  name=\"\" (change)=\"onChange(p.id, $event.target.checked)\" checked=\"true\">\n                  <button (click)=\"deleteProduct(p,p.is_front_two)\" title=\"Product delete from group\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></button>\n                  </div>\n                \n                  <input *ngIf=\"p.is_front==0\"  type=\"checkbox\" value=\"{{p.id}}\"  name=\"\" (change)=\"onChange(p.id, $event.target.checked)\" >\n                </td>\n              </tr>\n            </tbody>\n          </table>\n          <!-- <nav>\n            <ul class=\"pagination\">\n              <li class=\"page-item\"><a class=\"page-link\" href=\"#\">Prev</a></li>\n              <li class=\"page-item active\">\n                <a class=\"page-link\" href=\"#\">1</a>\n              </li>\n              <li class=\"page-item\"><a class=\"page-link\" href=\"#\">2</a></li>\n              <li class=\"page-item\"><a class=\"page-link\" href=\"#\">3</a></li>\n              <li class=\"page-item\"><a class=\"page-link\" href=\"#\">4</a></li>\n              <li class=\"page-item\"><a class=\"page-link\" href=\"#\">Next</a></li>\n            </ul>\n          </nav> -->\n        </div>\n      </div>\n    </div>\n    <!--/.col-->\n  </div>\n\n</ion-content>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=seller-seller-product-group-add-seller-product-group-add-module-es5.js.map