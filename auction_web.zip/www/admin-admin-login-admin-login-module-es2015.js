(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["admin-admin-login-admin-login-module"],{

/***/ "/Pd7":
/*!*****************************************************************!*\
  !*** ./src/app/admin/admin-login/admin-login-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: AdminLoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLoginPageRoutingModule", function() { return AdminLoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _admin_login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./admin-login.page */ "ynWH");




const routes = [
    {
        path: '',
        component: _admin_login_page__WEBPACK_IMPORTED_MODULE_3__["AdminLoginPage"]
    }
];
let AdminLoginPageRoutingModule = class AdminLoginPageRoutingModule {
};
AdminLoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AdminLoginPageRoutingModule);



/***/ }),

/***/ "Fbmq":
/*!*********************************************************!*\
  !*** ./src/app/admin/admin-login/admin-login.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/*-------- login area css start --------*/\n.login_area .login_body_area {\n  background: #f7f6ff;\n  padding: 50px 0px;\n}\n.login_area .login_body_area .login_body {\n  width: 100%;\n  max-width: 420px;\n  margin: 0 auto;\n}\n.login_area .login_body_area .login_body h1 {\n  color: #262262;\n  font-size: 36px;\n  font-weight: 500;\n  line-height: normal;\n  text-transform: capitalize;\n  text-align: center;\n  position: relative;\n  display: inline-block;\n}\n.login_area .login_body_area .login_body h1:after {\n  content: \"\";\n  position: absolute;\n  bottom: 6px;\n  right: 0;\n  width: 30px;\n  height: 3px;\n  background: #ed1c24;\n}\n.login_area .login_body_area .login_body .form-group {\n  position: relative;\n}\n.login_area .login_body_area .login_body .form-control {\n  font-size: 14px;\n  padding-left: 40px;\n}\n.login_area .login_body_area .login_body .form-group .icon {\n  content: \"\";\n  position: absolute;\n  bottom: 10px;\n  left: 12px;\n}\n.login_area .login_body_area .login_body .form-group .forgot_password {\n  float: right;\n  color: #262262;\n  font-weight: 500;\n  text-transform: capitalize;\n  text-decoration: underline;\n  -webkit-transition: 0.5s;\n  -moz-transition: 0.5s;\n  -o-transition: 0.5s;\n}\n.login_area .login_body_area .login_body .form-group .forgot_password:hover {\n  color: #ed1c24;\n}\n.login_area .login_body_area .login_body .btn {\n  padding-top: 15px;\n  padding-bottom: 15px;\n}\n.login_area .login_body_area .login_body h6 {\n  position: relative;\n  text-align: center;\n  margin: 24px 0;\n}\n.login_area .login_body_area .login_body h6:before {\n  content: \"\";\n  position: absolute;\n  top: 10px;\n  left: 0;\n  width: 100%;\n  height: 1px;\n  background: #e0e0e0;\n}\n.login_area .login_body_area .login_body h6 strong {\n  margin: 0 auto;\n  font-size: 16px;\n  font-weight: 400;\n  color: #969696;\n  background: #f7f6ff;\n  position: relative;\n  padding: 0 10px;\n}\n.login_area .login_body_area .login_body ul {\n  margin: 0 0;\n  padding: 0 0;\n  text-align: center;\n  list-style: none;\n}\n.login_area .login_body_area .login_body ul li {\n  display: inline-block;\n  margin-right: 8px;\n}\n.login_area .login_body_area .login_body ul li:last-child {\n  margin-right: 0px;\n}\n.login_area .login_body_area .login_body ul li .btn {\n  padding: 8px 35px;\n  text-transform: capitalize;\n}\n.login_area .login_body_area .login_body ul li .btn.btn-primary {\n  background: transparent !important;\n  color: #4c4c4c !important;\n  border-color: #e2878a !important;\n}\n.login_area .login_body_area .login_body ul li .btn.btn-primary:hover {\n  box-shadow: 0 0 4px #f78a8e !important;\n}\n.login_area .login_body_area .login_body ul li .btn.btn-success {\n  background: transparent !important;\n  color: #127ae7 !important;\n  border-color: #6863af !important;\n}\n.login_area .login_body_area .login_body ul li .btn.btn-success:hover {\n  box-shadow: 0 0 4px #7069c7 !important;\n}\n.login_area .login_body_area .login_body p {\n  margin: 20px 0 0;\n  padding: 0 0;\n  font-size: 15px;\n  font-weight: 500;\n  color: #525252;\n  text-align: center;\n}\n.login_area .login_body_area .login_body p a {\n  -webkit-transition: 0.5s;\n  -moz-transition: 0.5s;\n  -o-transition: 0.5s;\n  color: #262262;\n}\n.login_area .login_body_area .login_body p a:hover {\n  color: #ed1c24;\n}\n/*-------- login area css stop --------*/\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhZG1pbi1sb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEseUNBQUE7QUFFQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7QUFBSjtBQUVBO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUNKO0FBQ0E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtBQUVKO0FBQUE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFHSjtBQURBO0VBQ0ksa0JBQUE7QUFJSjtBQUZBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBS0o7QUFIQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FBTUo7QUFKQTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0Esd0JBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FBT0o7QUFMQTtFQUNJLGNBQUE7QUFRSjtBQU5BO0VBQ0ksaUJBQUE7RUFDQSxvQkFBQTtBQVNKO0FBUEE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQVVKO0FBUkE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFXSjtBQVRBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQVlKO0FBVkE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFhSjtBQVhBO0VBQ0kscUJBQUE7RUFDQSxpQkFBQTtBQWNKO0FBWkE7RUFDSSxpQkFBQTtBQWVKO0FBYkE7RUFDSSxpQkFBQTtFQUNBLDBCQUFBO0FBZ0JKO0FBZEE7RUFDSSxrQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUFpQko7QUFmQTtFQUNJLHNDQUFBO0FBa0JKO0FBaEJBO0VBQ0ksa0NBQUE7RUFDQSx5QkFBQTtFQUNBLGdDQUFBO0FBbUJKO0FBakJBO0VBQ0ksc0NBQUE7QUFvQko7QUFsQkE7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFxQko7QUFuQkE7RUFDSSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBc0JKO0FBcEJBO0VBQ0ksY0FBQTtBQXVCSjtBQXJCQSx3Q0FBQSIsImZpbGUiOiJhZG1pbi1sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKi0tLS0tLS0tIGxvZ2luIGFyZWEgY3NzIHN0YXJ0IC0tLS0tLS0tKi9cbi5sb2dpbl9hcmVhe31cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWF7XG4gICAgYmFja2dyb3VuZDogI2Y3ZjZmZjtcbiAgICBwYWRkaW5nOiA1MHB4IDBweDtcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHl7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWF4LXdpZHRoOiA0MjBweDtcbiAgICBtYXJnaW46IDAgYXV0bztcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgaDF7XG4gICAgY29sb3I6ICMyNjIyNjI7XG4gICAgZm9udC1zaXplOiAzNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgaDE6YWZ0ZXJ7XG4gICAgY29udGVudDogJyc7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogNnB4O1xuICAgIHJpZ2h0OiAwO1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogM3B4O1xuICAgIGJhY2tncm91bmQ6ICNlZDFjMjQ7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IC5mb3JtLWdyb3Vwe1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgLmZvcm0tY29udHJvbHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgcGFkZGluZy1sZWZ0OiA0MHB4O1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSAuZm9ybS1ncm91cCAuaWNvbntcbiAgICBjb250ZW50OiAnJztcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm90dG9tOiAxMHB4O1xuICAgIGxlZnQ6IDEycHg7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IC5mb3JtLWdyb3VwIC5mb3Jnb3RfcGFzc3dvcmR7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGNvbG9yOiAjMjYyMjYyO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiAwLjVzO1xuICAgIC1tb3otdHJhbnNpdGlvbjogMC41cztcbiAgICAtby10cmFuc2l0aW9uOiAwLjVzO1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSAuZm9ybS1ncm91cCAuZm9yZ290X3Bhc3N3b3JkOmhvdmVye1xuICAgIGNvbG9yOiAjZWQxYzI0O1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSAuYnRue1xuICAgIHBhZGRpbmctdG9wOiAxNXB4O1xuICAgIHBhZGRpbmctYm90dG9tOiAxNXB4O1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSBoNntcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogMjRweCAwO1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSBoNjpiZWZvcmV7XG4gICAgY29udGVudDogJyc7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMTBweDtcbiAgICBsZWZ0OiAwO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMXB4O1xuICAgIGJhY2tncm91bmQ6ICNlMGUwZTA7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IGg2IHN0cm9uZ3tcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzk2OTY5NjtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmNmZmO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IHVse1xuICAgIG1hcmdpbjogMCAwO1xuICAgIHBhZGRpbmc6IDAgMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgdWwgbGl7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIG1hcmdpbi1yaWdodDogOHB4O1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSB1bCBsaTpsYXN0LWNoaWxke1xuICAgIG1hcmdpbi1yaWdodDogMHB4O1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSB1bCBsaSAuYnRue1xuICAgIHBhZGRpbmc6IDhweCAzNXB4O1xuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSB1bCBsaSAuYnRuLmJ0bi1wcmltYXJ5e1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICM0YzRjNGMgIWltcG9ydGFudDtcbiAgICBib3JkZXItY29sb3I6ICNlMjg3OGEgIWltcG9ydGFudDtcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgdWwgbGkgLmJ0bi5idG4tcHJpbWFyeTpob3ZlcntcbiAgICBib3gtc2hhZG93OiAwIDAgNHB4IHJnYigyNDcgMTM4IDE0MikgIWltcG9ydGFudDtcbn1cbi5sb2dpbl9hcmVhIC5sb2dpbl9ib2R5X2FyZWEgLmxvZ2luX2JvZHkgdWwgbGkgLmJ0bi5idG4tc3VjY2Vzc3tcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIGNvbG9yOiAjMTI3YWU3ICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyLWNvbG9yOiAjNjg2M2FmICFpbXBvcnRhbnQ7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IHVsIGxpIC5idG4uYnRuLXN1Y2Nlc3M6aG92ZXJ7XG4gICAgYm94LXNoYWRvdzogMCAwIDRweCByZ2IoMTEyIDEwNSAxOTkpICFpbXBvcnRhbnQ7XG59XG4ubG9naW5fYXJlYSAubG9naW5fYm9keV9hcmVhIC5sb2dpbl9ib2R5IHB7XG4gICAgbWFyZ2luOiAyMHB4IDAgMDtcbiAgICBwYWRkaW5nOiAwIDA7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgY29sb3I6ICM1MjUyNTI7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSBwIGF7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiAwLjVzO1xuICAgIC1tb3otdHJhbnNpdGlvbjogMC41cztcbiAgICAtby10cmFuc2l0aW9uOiAwLjVzO1xuICAgIGNvbG9yOiAjMjYyMjYyO1xufVxuLmxvZ2luX2FyZWEgLmxvZ2luX2JvZHlfYXJlYSAubG9naW5fYm9keSBwIGE6aG92ZXJ7XG4gICAgY29sb3I6ICNlZDFjMjQ7XG59XG4vKi0tLS0tLS0tIGxvZ2luIGFyZWEgY3NzIHN0b3AgLS0tLS0tLS0qLyJdfQ== */");

/***/ }),

/***/ "LiIn":
/*!*********************************************************!*\
  !*** ./src/app/admin/admin-login/admin-login.module.ts ***!
  \*********************************************************/
/*! exports provided: AdminLoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLoginPageModule", function() { return AdminLoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_include_include_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/include/include.module */ "+TEy");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _admin_login_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./admin-login-routing.module */ "/Pd7");
/* harmony import */ var _admin_login_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./admin-login.page */ "ynWH");








let AdminLoginPageModule = class AdminLoginPageModule {
};
AdminLoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _admin_login_routing_module__WEBPACK_IMPORTED_MODULE_6__["AdminLoginPageRoutingModule"],
            src_app_include_include_module__WEBPACK_IMPORTED_MODULE_2__["IncludeModule"]
        ],
        declarations: [_admin_login_page__WEBPACK_IMPORTED_MODULE_7__["AdminLoginPage"]]
    })
], AdminLoginPageModule);



/***/ }),

/***/ "bbVK":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin-login/admin-login.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content [fullscreen]=\"true\" [scrollEvents]=\"true\" (ionScroll)=\"logScrolling($event)\">\n  <app-header></app-header>\n  <section class=\"main_area login_area\">\n    <div class=\"container\">\n\n      <div class=\"login_body_area\">\n        <div class=\"login_body\">\n          <form [formGroup]=\"loginForm\">\n            <div class=\"text-center\">\n              <h1>Admin Login</h1>\n            </div>\n            <div class=\"form-group\">\n              <label>E-mail Address</label>\n              <input type=\"text\" class=\"form-control\"\n              [ngClass]=\"{ 'is-invalid': submitted && f.email.errors }\" formControlName=\"email\" autocomplete=\"off\"\n                placeholder=\"Please enter Email/Bidder ID\">\n              <div class=\"icon\"><img src=\"assets/images/login-user.png\" alt=\"login user\"></div>\n              <div *ngIf=\"submitted && f.email.errors\" class=\"invalid-feedback\">\n                <div *ngIf=\"f.email.errors.required\">Email is required</div>\n              </div>\n            </div>\n            <div class=\"form-group\">\n              <label>Password</label>\n              <input type=\"password\" class=\"form-control\"\n              [ngClass]=\"{ 'is-invalid': submitted && f.password.errors }\" formControlName=\"password\" autocomplete=\"off\"\n                placeholder=\"Please enter password\">\n              <div class=\"icon\"><img src=\"assets/images/login-password.png\" alt=\"login user\"></div>\n              <div *ngIf=\"submitted && f.password.errors\" class=\"invalid-feedback\">\n                <div *ngIf=\"f.password.errors.required\">Password is required</div>\n              </div>\n            </div>\n            <div class=\"form-group form-check\">\n              <label class=\"form-check-label\">\n                <input class=\"form-check-input\" type=\"checkbox\"> Remember me\n              </label>\n              <a href=\"#\" class=\"forgot_password\">forgot password</a>\n            </div>\n            <button class=\"btn btn-primary w-100\" (click)=\"onSubmit()\">login</button>\n          </form>\n          <!-- <h6><strong>or login with</strong></h6>\n          <ul>\n            <li>\n              <button class=\"btn btn-primary\">\n                <img src=\"assets/images/google.png\" alt=\"google\" title=\"\" class=\"mr-2\">\n                Google\n              </button>\n            </li>\n            <li>\n              <button class=\"btn btn-success\">\n                <img src=\"assets/images/login-facebook.png\" alt=\"facebook\" title=\"\" class=\"mr-2\">\n                facebook\n              </button>\n            </li>\n          </ul> -->\n         \n        </div>\n      </div>\n\n    </div>\n  </section>\n  <app-footer></app-footer>\n\n</ion-content>");

/***/ }),

/***/ "ynWH":
/*!*******************************************************!*\
  !*** ./src/app/admin/admin-login/admin-login.page.ts ***!
  \*******************************************************/
/*! exports provided: AdminLoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLoginPage", function() { return AdminLoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_admin_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./admin-login.page.html */ "bbVK");
/* harmony import */ var _admin_login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./admin-login.page.scss */ "Fbmq");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/storage-angular */ "jSNZ");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/environments/environment */ "AytR");










let AdminLoginPage = class AdminLoginPage {
    constructor(storage, router, loadingController, http, formBuilder, alertController) {
        this.storage = storage;
        this.router = router;
        this.loadingController = loadingController;
        this.http = http;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.submitted = false;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].API_URL;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loginForm = this.formBuilder.group({
                email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email]],
                password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]]
            });
            yield this.storage.create();
        });
    }
    ionViewDidEnter() {
        this.storage.get('auctionAdmin').then(response => {
            //console.log(response);
            if (response != null) {
                //console.log(response.response_data);
                if (response.response_data.role_text == "Admin") {
                    this.router.navigate(['/admin/dashboard']);
                }
            }
            else {
                this.router.navigate(['/admin-login']);
            }
        }, err => {
        });
    }
    onSubmit() {
        this.submitted = true;
        if (this.loginForm.invalid) {
            return;
        }
        else {
            this.loadingShow();
            let formData = new FormData;
            formData.append('email', this.loginForm.value.email);
            formData.append('password', this.loginForm.value.password);
            this.http.post(this.url + 'user-login', formData).subscribe((res) => {
                if (res && res.status) {
                    if (res.response_data.role_text == 'Admin') {
                        this.storage.set('auctionAdmin', res).then(response => {
                            this.loadingHide();
                            this.router.navigate(['/admin/dashboard']);
                        });
                    }
                    else {
                        this.loadingHide();
                        this.presentAlert('Error!', '', 'Please check username & password');
                    }
                }
                else {
                    this.loadingHide();
                    this.presentAlert('Error!', '', res.message ? res.message : 'Please try again later');
                }
            }, err => {
                this.loadingHide();
                this.presentAlert('Error!', '', 'Server error, please try again later');
            });
        }
    }
    logScrolling(event) {
        if (event.detail.scrollTop > 100) {
            $('.header_bottom').addClass("fix");
        }
        else {
            $('.header_bottom').removeClass("fix");
        }
    }
    get f() { return this.loginForm.controls; }
    presentAlert(header, subHeader, message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header,
                subHeader,
                message,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    loadingShow() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                message: 'Please wait...',
                duration: 4000
            });
            yield this.loading.present();
        });
    }
    loadingHide() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.loading) {
                yield this.loading.dismiss();
            }
        });
    }
};
AdminLoginPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_8__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"] }
];
AdminLoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-admin-login',
        template: _raw_loader_admin_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_admin_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AdminLoginPage);



/***/ })

}]);
//# sourceMappingURL=admin-admin-login-admin-login-module-es2015.js.map